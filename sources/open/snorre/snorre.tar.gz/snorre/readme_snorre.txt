﻿Wordlist extracted from the terminlogy database SNORRE (The SNORRE wordlist)

SNORRE is a database containing terminology from many differtent subject areas.
The database has been developed by Standards Norway in cooperation with The Language Council of Norway. The database is the result of standardisation work.
SNORRE contains terminology in Norwegian Bokmål, Norwegian Nynorsk, English, French and German, as well as synonyms and abbreviations in the same languages.

This version of SNORRE is a wordlist extracted from the database, containing all the terms, parallelised for the various languages. The definitions are not included.


File format

Tab-separated plain text.


Contents
                    Terms   Syn.  Abbr.
Norwegian Bokmål   49.678  2.257    945
Norwegian Nynorsk  48.875  3.448    900
English            48.213  3.012  1.024
French             17.623    843    423
German             18.749    876    203

The total amount of unique terms amounts to 53.486.


Conditions of use

Standards Norway has developed and holds the copyright for the SNORRE wordlist.

Språkbanken's users may freely use the SNORRE wordlist, provided Standards Norge is always cited as copyright holder.

Språkbanken will distribute this version of the SNORRE wordlist until December 15 2014.


Contact information

Any questions regarding the SNORRE wordlist may be directed to Språkbanken via e-mail: sprakbanken@nb.no.
National Library of Norway, 2013-03-12
